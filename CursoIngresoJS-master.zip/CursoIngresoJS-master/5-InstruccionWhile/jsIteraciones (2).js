function mostrar()
{
	alert('iteración while');

	{
		//CON FOR

		for (var contador =10; contador >0; contador --){

			console.log (contador);
		}

	}


}//FIN DE LA FUNCIÓN