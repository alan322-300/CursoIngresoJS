function mostrar()
{

	var contador=0;
	var acumulador=0;
	var respuesta='si';
	var suma= 0;


	while (respuesta != `no`){
		do{
			numero=prompt
			numero= parseInt(numero)
		
		}while (isNaN(numero))
		suma= numero
	}


document.getElementById('suma').value=acumulador;
document.getElementById('promedio').value=acumulador/contador;

}//FIN DE LA FUNCIÓN